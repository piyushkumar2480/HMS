import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imp-updates',
  templateUrl: './imp-updates.component.html',
  styleUrls: ['./imp-updates.component.css']
})
export class ImpUpdatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
