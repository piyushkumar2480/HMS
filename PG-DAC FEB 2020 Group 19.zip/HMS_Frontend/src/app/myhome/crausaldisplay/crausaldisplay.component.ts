import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crausaldisplay',
  templateUrl: './crausaldisplay.component.html',
  styleUrls: ['./crausaldisplay.component.css']
})
export class CrausaldisplayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
