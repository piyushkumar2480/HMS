import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uppernavbar',
  templateUrl: './uppernavbar.component.html',
  styleUrls: ['./uppernavbar.component.css']
})
export class UppernavbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
