import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upperfooter',
  templateUrl: './upperfooter.component.html',
  styleUrls: ['./upperfooter.component.css']
})
export class UpperfooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
