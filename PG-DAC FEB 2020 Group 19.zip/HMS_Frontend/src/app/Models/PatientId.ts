export class PatientId{
    constructor(
        public id:number
    ){}
}