export class RegisterPatient{
    public constructor(
        //public id:number,
       public name:string,
       public password:string,
       public email:string,
       public address:string,
       public primary_phoneNo:string,
       public alt_phoneNo:string,
       public dob:string,
       public blood_grp:string,
       public gender:string,
        ){}
}