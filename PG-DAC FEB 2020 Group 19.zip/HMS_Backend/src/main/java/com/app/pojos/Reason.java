package com.app.pojos;

public enum Reason {

	general , kidney ,heart
}
